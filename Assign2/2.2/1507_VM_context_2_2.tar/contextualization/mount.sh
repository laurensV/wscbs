mkdir /home/ubuntu/pmk-seeds
mkdir /root/tweets
mount /dev/sdb /root/tweets
