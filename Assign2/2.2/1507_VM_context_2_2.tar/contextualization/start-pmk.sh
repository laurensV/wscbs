tmux new -d -s pmk 'cd /home/ubuntu/pumpkin && python DRHarness.py --supernode --broadcast --taskdir /home/ubuntu/pmk-seeds/ -c /home/ubuntu/pumpkin/pumpkin.cfg --gonzales --endpoints="tcp://*:*"'
